```
npm install
npm run start
```

```
open http://localhost:3000
```
