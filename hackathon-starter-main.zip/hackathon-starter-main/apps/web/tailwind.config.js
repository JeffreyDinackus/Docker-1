module.exports = require('ui/tailwind.config');
